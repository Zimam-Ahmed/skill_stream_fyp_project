import express from 'express';
const router = express.Router();
import { protect } from '../middlewares/authMiddleware.js';
import {
  createClassWork,
  getClassworksByClassId,
} from '../controllers/classWorkController.js';


// Create classwork
router.route('/').post(protect, createClassWork);

// Route to get all classworks by classId
router.route('/classworks/:classId').get(protect, getClassworksByClassId);


export default router;
