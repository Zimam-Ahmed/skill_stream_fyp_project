import Classwork from '../models/classWorkModel.js';
import asyncHandler from 'express-async-handler';
import multer from 'multer';
import path from 'path';
import fs from 'fs';

// Set up Multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Create a folder for each classwork
    const folder = path.join('public', 'uploads', req.body.title.replace(/ /g, '_'));
    console.log(folder);
    fs.mkdirSync(folder, { recursive: true });
    cb(null, folder);
  },
  filename: function (req, file, cb) {
    console.log(file.originalname);
    // Use the original file name
    cb(null, file.originalname);
    
  },
  
}); 

const upload = multer({ storage: storage });

// Create a new classwork with file upload
const createClassWork = asyncHandler(upload.single('file'), async (req, res) => {
  
  console.log(req.file);
  const { title, discription, type, points, classId, duedate, } = req.body;
   
  if (req.file) {
    return res.status(400).json({ message: 'No file uploaded' });
  }

  // The file is available as req.file
  const filename = req.file.originalname;

  try {
    const classwork = await Classwork.create({
      title,
      discription,
      type,
      points,
      classId,
      createdBy: req.body.createdBy._id,
      duedate,
      file: req.file, // Store the file name in the 'file' field
    }); 
    if (classwork) {
      res.status(201).json({
        _id: classwork._id,
        title: classwork.title,
        discription: classwork.discription,
        type: classwork.type,
        points: classwork.points,
        classId: classwork.classId,
        createdBy: classwork.createdBy,
        duedate: classwork.duedate,
        file: {
          filename: filename, // Store the original filename
        },
      });
    } else {
      res.status(400);
      throw new Error('Invalid data');
    }
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
 
});

const getClassworksByClassId = asyncHandler(async (req, res) => {
  // Get the classId from the route params
  const { classId } = req.params;
  console.log(req.classId);
  // Query the Classwork model to find all classworks with the given classId
  const classwork = await Classwork.find({ classId });
  
  if (classwork) {
    res.status(200).json(classwork);
  } else {
    res.status(404);
    throw new Error('Classworks not found');
  }
});

export { createClassWork, getClassworksByClassId };
